import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
} from "react";
import {
  setAudioModeAsync,
  useAudioPlayer,
  useAudioPlayerStatus,
  type AudioMetadata,
} from "expo-audio";
import { getMusicStream } from "@workspace/api-client-react";

export interface YoutubeAudioHandle {
  loadVideo: (videoId: string, metadata?: AudioMetadata) => Promise<void>;
  play: () => void;
  pause: () => void;
  seekTo: (seconds: number) => Promise<void>;
  getCurrentTime: () => number;
  getDuration: () => number;
}

interface Props {
  onPlay?: () => void;
  onPause?: () => void;
  onEnded?: () => void;
  onBuffering?: () => void;
  onTimeUpdate?: (currentTime: number) => void;
  onDurationChange?: (duration: number) => void;
  onError?: () => void;
}

const YoutubeAudioBridge = forwardRef<YoutubeAudioHandle, Props>(
  ({ onPlay, onPause, onEnded, onBuffering, onTimeUpdate, onDurationChange, onError }, ref) => {
    const player = useAudioPlayer(null, {
      updateInterval: 500,
      keepAudioSessionActive: true,
    });
    const status = useAudioPlayerStatus(player);
    const requestIdRef = useRef(0);
    const metadataRef = useRef<AudioMetadata | undefined>(undefined);

    useEffect(() => {
      void setAudioModeAsync({
        playsInSilentMode: true,
        interruptionMode: "doNotMix",
        allowsRecording: false,
        shouldPlayInBackground: true,
        shouldRouteThroughEarpiece: false,
      }).catch(() => {
        // The player still works in foreground if the audio session cannot be configured.
      });
    }, []);

    useEffect(() => {
      if (Number.isFinite(status.currentTime)) onTimeUpdate?.(status.currentTime);
      if (Number.isFinite(status.duration) && status.duration > 0) {
        onDurationChange?.(status.duration);
      }
      if (status.isBuffering) onBuffering?.();
      if (status.playing) onPlay?.();
      else if (status.isLoaded && !status.didJustFinish) onPause?.();
      if (status.didJustFinish) onEnded?.();
    }, [
      status.currentTime,
      status.duration,
      status.isBuffering,
      status.playing,
      status.isLoaded,
      status.didJustFinish,
      onTimeUpdate,
      onDurationChange,
      onBuffering,
      onPlay,
      onPause,
      onEnded,
    ]);

    useImperativeHandle(ref, () => ({
      loadVideo: async (id: string, metadata?: AudioMetadata) => {
        const requestId = ++requestIdRef.current;
        metadataRef.current = metadata;
        try {
          const stream = await getMusicStream(id);
          if (requestId !== requestIdRef.current) return;
          player.replace({ uri: stream.url });
          player.setActiveForLockScreen(true, metadata, {
            showSeekForward: true,
            showSeekBackward: true,
          });
          player.play();
        } catch {
          if (requestId === requestIdRef.current) onError?.();
          throw new Error("Unable to load audio stream");
        }
      },
      play: () => player.play(),
      pause: () => player.pause(),
      seekTo: (seconds: number) => player.seekTo(seconds),
      getCurrentTime: () => status.currentTime,
      getDuration: () => status.duration,
    }), [onError, player, status.currentTime, status.duration]);

    useEffect(() => {
      if (metadataRef.current && status.isLoaded) {
        player.updateLockScreenMetadata(metadataRef.current);
      }
    }, [player, status.isLoaded]);

    return null;
  },
);

YoutubeAudioBridge.displayName = "YoutubeAudioBridge";
export default YoutubeAudioBridge;
