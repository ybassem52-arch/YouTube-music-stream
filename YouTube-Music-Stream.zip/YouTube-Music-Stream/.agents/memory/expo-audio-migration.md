---
name: expo-audio migration
description: How to use expo-audio in an Expo SDK 54 app after expo-av deprecation
---

## Rule
In Expo SDK 54, install expo-audio@~1.1.1 (NOT the 56.x version pnpm might resolve). Use useAudioPlayer(null) at provider level, then call player.replace({uri}) imperatively to swap tracks.

**Why:** expo-av is removed in SDK 54. expo-audio's AudioPlayerOptions does NOT have a shouldPlay field — omit it. seekTo returns Promise<void> (no need to await in practice).

**How to apply:**
- useAudioPlayer(null) — start with no source
- player.replace({ uri: streamUrl }) then player.play() when loading a new song
- useAudioPlayerStatus(player) gives { playing, currentTime, duration, didJustFinish }
- expo-audio 1.1.x supports web via HTML Audio element natively
