---
name: YouTube audio in Expo
description: How to play YouTube audio in an Expo app without server-side extraction
---

# Rule
Never use server-side YouTube extraction for browser/Expo web playback. Web stays on the YouTube IFrame Player API. Native Android can use `expo-audio` with YouTube's current Android `serverAbrStreamingUrl`, but that returns the SABR/UMP transport rather than a conventional MP4 URL and still needs physical-device validation.

**Why:** YouTube has blocked all server-side client types (iOS, ANDROID, MWEB, WEB, TVHTML5) from returning playable stream URLs without cipher decoding. ytdl-core/youtubei.js both fail — ytdl-core can't parse cipher functions, youtubei.js requires a custom JS evaluator (node:vm) which also fails because MWEB format objects have no url or signatureCipher populated. The IFrame approach uses YouTube's own player which handles all cipher/DRM internally.

**How to apply:**
- `components/YoutubeAudioBridge.web.tsx` — Web: loads YouTube IFrame API script, creates hidden player div at position -9999, exposes `loadVideo`, `play`, `pause`, `seekTo` via `forwardRef`.
- `components/YoutubeAudioBridge.tsx` — Native: uses `react-native-youtube-iframe` with height=0.
- `context/MusicContext.tsx` — holds a ref to the native audio bridge and passes song metadata for lock-screen controls. The web bridge remains separate.
- The API can resolve the current Android SABR endpoint through `youtubei.js`, but do not assume the URL is a normal downloadable audio file; YouTube changes this transport frequently.

**Why:** YouTube removed conventional playable URLs from the Android InnerTube response in the current environment. The Android-native route is the closest available path for background playback without an IFrame, while web playback must keep using YouTube's own player.

**How to apply:** Validate the native stream on a real Android build before promising production reliability. Keep the web implementation on the IFrame path unless a supported browser-native source is introduced.
