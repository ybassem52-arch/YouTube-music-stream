---
name: ymusic audio backend
description: How the ymusic app sources music metadata and stream URLs without any API key
---

## Rule
Use YouTube Innertube API (POST to youtubei/v1/search) for metadata, @distube/ytdl-core for stream URL extraction. Do NOT use Invidious — all public instances are either shutdown or rate-limit aggressively.

**Why:** Invidious instances return 401/502/404. Piped API also unreliable. YouTube's internal key (AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8) is the same one used by the YouTube website itself and remains stable across clients.

**How to apply:**
- Search/trending: POST https://www.youtube.com/youtubei/v1/search?key=<key> with context client WEB 2.20231121.08.00
- Streams: @distube/ytdl-core getInfo() then filterFormats('audioonly') — may show cipher warnings but still returns itag=18 combined format that plays fine in expo-audio
- Return 200 with empty songs array on failure (never 500) for resilience
