---
name: Android APK builds
description: Replit Expo delivery limits and local Android tooling availability for this project
---

Replit's current Expo workflow supports Android preview through Expo Go and QR code, but does not provide a direct APK download button. This workspace does not have a local Android SDK or Java toolchain available for building an APK in place.

**Why:** A request for a downloadable Android installer cannot be completed with the preview workflow alone.

**How to apply:** Offer Expo Go preview for immediate testing; do not claim that a downloadable APK was produced unless a supported external build flow is explicitly available.