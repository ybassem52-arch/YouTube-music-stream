import { pgTable, timestamp, varchar, integer } from "drizzle-orm/pg-core";
import { usersTable } from "./auth";

export const playlistsTable = pgTable("playlists", {
  id: varchar("id").primaryKey().default("gen_random_uuid()"),
  userId: varchar("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  name: varchar("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const playlistSongsTable = pgTable("playlist_songs", {
  id: varchar("id").primaryKey().default("gen_random_uuid()"),
  playlistId: varchar("playlist_id").notNull().references(() => playlistsTable.id, { onDelete: "cascade" }),
  videoId: varchar("video_id").notNull(),
  title: varchar("title").notNull(),
  artist: varchar("artist").notNull(),
  thumbnail: varchar("thumbnail").notNull(),
  duration: varchar("duration").notNull().default(""),
  position: integer("position").notNull().default(0),
  addedAt: timestamp("added_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Playlist = typeof playlistsTable.$inferSelect;
export type InsertPlaylist = typeof playlistsTable.$inferInsert;
export type PlaylistSong = typeof playlistSongsTable.$inferSelect;
export type InsertPlaylistSong = typeof playlistSongsTable.$inferInsert;
