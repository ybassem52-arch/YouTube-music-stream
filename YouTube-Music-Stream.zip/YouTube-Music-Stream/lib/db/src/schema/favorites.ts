import { pgTable, timestamp, varchar } from "drizzle-orm/pg-core";
import { usersTable } from "./auth";

export const favoritesTable = pgTable("favorites", {
  id: varchar("id").primaryKey().default("gen_random_uuid()"),
  userId: varchar("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  videoId: varchar("video_id").notNull(),
  title: varchar("title").notNull(),
  artist: varchar("artist").notNull(),
  thumbnail: varchar("thumbnail").notNull(),
  duration: varchar("duration").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Favorite = typeof favoritesTable.$inferSelect;
export type InsertFavorite = typeof favoritesTable.$inferInsert;
